import streamlit as st
import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
from utils import save_uploaded_files, draw_bounding_boxes
from model_loader import run_detection_pipeline

# Page Config
st.set_page_config(
    page_title="Cricket Object Detection",
    page_icon="🏏",
    layout="wide"
)

# Constants
INPUT_DIR = "input_images"

# Create input directory if it doesn't exist
Path(INPUT_DIR).mkdir(exist_ok=True)

# Initialize Session State
if 'results' not in st.session_state:
    st.session_state.results = None
if 'uploaded_count' not in st.session_state:
    st.session_state.uploaded_count = 0

def main():
    st.title("🏏 Cricket Object Detection System")
    st.markdown("Upload match images to detect players, bats, balls, and wickets.")

    # Sidebar for Navigation
    page = st.sidebar.radio("Navigate", ["Upload & Detect", "Graphical Analytics"])

    if page == "Upload & Detect":
        render_upload_section()
    elif page == "Graphical Analytics":
        render_analytics_section()

def render_upload_section():
    st.header("1. Upload Images")
    st.markdown("Upload one or more cricket images. They will be saved to the directory and processed by the detection model.")
    
    # Display current uploaded count
    existing_images = len([f for f in os.listdir(INPUT_DIR) if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
    st.info(f"📁 Current images in directory: **{existing_images}**")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        # File Uploader
        uploaded_files = st.file_uploader(
            "Choose cricket images to upload", 
            type=['png', 'jpg', 'jpeg'], 
            accept_multiple_files=True,
            key="image_uploader"
        )
    
    with col2:
        # Clear directory button
        if st.button("🗑️ Clear All", type="secondary"):
            if os.path.exists(INPUT_DIR):
                import shutil
                shutil.rmtree(INPUT_DIR)
                os.makedirs(INPUT_DIR)
            st.session_state.results = None
            st.success("Directory cleared!")
            st.rerun()

    # Process Button
    if uploaded_files:
        st.success(f"✅ {len(uploaded_files)} image(s) selected for upload.")
        
        col_run, col_info = st.columns([1, 3])
        
        with col_run:
            run_detection = st.button("🚀 Save & Run Model", type="primary")
        
        with col_info:
            st.write("Images will be added to the directory and processed immediately.")
        
        if run_detection:
            try:
                with st.spinner("📤 Uploading images and running detection pipeline..."):
                    # Save files to directory (appends to existing)
                    save_uploaded_files(uploaded_files, INPUT_DIR, append=True)
                    st.session_state.uploaded_count += len(uploaded_files)
                    
                    # Invoke the model
                    results = run_detection_pipeline(INPUT_DIR)
                    st.session_state.results = results
                    
                st.success("✅ Detection Complete!")
                st.balloons()
            except Exception as e:
                st.error(f"❌ Error during processing: {str(e)}")
    
    # Display Results
    if st.session_state.results:
        st.markdown("---")
        st.header("2. Detection Results")
        st.markdown(f"Displaying results for **{len(st.session_state.results)}** processed image(s)")
        
        # Create tabs for different views
        tab1, tab2 = st.tabs(["Image Gallery", "Detailed Results"])
        
        with tab1:
            # Create a grid layout for images
            cols = st.columns(3)
            for idx, res in enumerate(st.session_state.results):
                col = cols[idx % 3]
                img_path = os.path.join(INPUT_DIR, res['filename'])
                
                # Draw boxes using the results
                annotated_img = draw_bounding_boxes(img_path, res['detections'])
                
                with col:
                    if annotated_img:
                        st.image(annotated_img, caption=res['filename'], use_container_width=True)
                        st.caption(f"🕐 Processed: {res.get('processed_at', 'N/A')}")
                    else:
                        st.warning(f"Could not process {res['filename']}")
        
        with tab2:
            st.subheader("Detection Details")
            for res in st.session_state.results:
                with st.expander(f"📄 {res['filename']} - {len(res['detections'])} objects detected"):
                    st.json(res['detections'])

def render_analytics_section():
    st.header("📊 Model Performance Analytics")
    
    if not st.session_state.results:
        st.warning("❌ No data available. Please upload and process images in the 'Upload & Detect' tab first.")
        st.info("Steps: 1) Go to 'Upload & Detect' tab → 2) Upload images → 3) Click 'Save & Run Model' → 4) Return here")
        return

    results = st.session_state.results
    
    try:
        # --- Data Preparation for Graphs ---
        all_detections = []
        for r in results:
            all_detections.extend(r['detections'])
        
        if not all_detections:
            st.warning("No detections found in the processed images.")
            return
        
        df = pd.DataFrame(all_detections)

        # Key Metrics Row
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("📷 Images Processed", len(results))
        col2.metric("🎯 Total Objects Detected", len(df))
        col3.metric("⭐ Avg Confidence", f"{df['confidence'].mean():.1%}")
        col4.metric("🔝 Max Confidence", f"{df['confidence'].max():.1%}")

        st.markdown("---")

        # --- Graphical Representations ---
        
        # Create tabs for different analytics views
        tab1, tab2, tab3, tab4 = st.tabs(["📊 Distribution", "📈 Confidence Analysis", "🎯 Class Breakdown", "📋 Data Table"])
        
        with tab1:
            st.subheader("Object Class Distribution")
            class_counts = df['class'].value_counts()
            
            col_bar, col_pie = st.columns(2)
            
            with col_bar:
                st.bar_chart(class_counts)
            
            with col_pie:
                fig, ax = plt.subplots(figsize=(8, 6))
                colors = plt.cm.Set3(np.linspace(0, 1, len(class_counts)))
                ax.pie(class_counts.values, labels=class_counts.index, autopct='%1.1f%%', colors=colors, startangle=90)
                ax.set_title("Class Distribution")
                st.pyplot(fig)

        with tab2:
            st.subheader("Confidence Score Analysis")
            
            col_hist, col_stats = st.columns([2, 1])
            
            with col_hist:
                # Histogram
                fig, ax = plt.subplots(figsize=(10, 5))
                ax.hist(df['confidence'], bins=15, color='#1f77b4', edgecolor='black', alpha=0.7)
                ax.axvline(df['confidence'].mean(), color='red', linestyle='--', linewidth=2, label=f"Mean: {df['confidence'].mean():.2f}")
                ax.axvline(df['confidence'].median(), color='green', linestyle='--', linewidth=2, label=f"Median: {df['confidence'].median():.2f}")
                ax.set_xlabel("Confidence Score", fontsize=11)
                ax.set_ylabel("Frequency", fontsize=11)
                ax.set_title("Confidence Score Distribution")
                ax.legend()
                st.pyplot(fig)
            
            with col_stats:
                st.markdown("### Statistics")
                st.write(f"**Mean:** {df['confidence'].mean():.3f}")
                st.write(f"**Median:** {df['confidence'].median():.3f}")
                st.write(f"**Std Dev:** {df['confidence'].std():.3f}")
                st.write(f"**Min:** {df['confidence'].min():.3f}")
                st.write(f"**Max:** {df['confidence'].max():.3f}")

        with tab3:
            st.subheader("Detailed Class Analysis")
            
            # Class-wise statistics
            class_stats = df.groupby('class')['confidence'].agg(['count', 'mean', 'min', 'max', 'std'])
            class_stats.columns = ['Count', 'Avg Confidence', 'Min', 'Max', 'Std Dev']
            st.dataframe(class_stats, use_container_width=True)
            
            st.markdown("")
            col_box, col_scatter = st.columns(2)
            
            with col_box:
                # Box plot by class
                fig, ax = plt.subplots(figsize=(10, 5))
                df.boxplot(column='confidence', by='class', ax=ax)
                ax.set_title("Confidence Distribution by Class")
                ax.set_xlabel("Class")
                ax.set_ylabel("Confidence Score")
                plt.suptitle('')  # Remove the automatic title
                st.pyplot(fig)
            
            with col_scatter:
                # Scatter plot
                fig, ax = plt.subplots(figsize=(10, 5))
                for class_name in df['class'].unique():
                    class_data = df[df['class'] == class_name]
                    ax.scatter(range(len(class_data)), class_data['confidence'], label=class_name, s=50, alpha=0.6)
                ax.set_xlabel("Detection Index")
                ax.set_ylabel("Confidence Score")
                ax.set_title("Confidence Scores by Detection")
                ax.legend()
                ax.grid(alpha=0.3)
                st.pyplot(fig)

        with tab4:
            st.subheader("Raw Detection Data")
            st.dataframe(df, use_container_width=True)
            
            # Download option
            csv = df.to_csv(index=False)
            st.download_button(
                label="📥 Download Results as CSV",
                data=csv,
                file_name="detection_results.csv",
                mime="text/csv"
            )
    
    except Exception as e:
        st.error(f"❌ Error generating analytics: {str(e)}")
        st.info("This might occur if the detection data format is unexpected. Check your model output.")

if __name__ == "__main__":
    main()
